function getData(){
    debugger;
    var xhttp = new XMLHttpRequest();

    xhttp.open("GET", "https://www.themealdb.com/api/json/v1/1/search.php?s=biryani", true);
    xhttp.send();

    xhttp.onreadystatechange = function(){
        if(this.readyState === 4 && this.status === 200){
            document.getElementById("divData").innerHTML = this.responseText;
        }
    }
}