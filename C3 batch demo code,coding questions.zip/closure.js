function init() {
    var name = 'Param'; // name is a local variable created by init
    function displayName() { // displayName() is the inner function, a closure
        alert(name); // use variable declared in the parent function
    }
    setTimeout(displayName, 5000);
}

init();