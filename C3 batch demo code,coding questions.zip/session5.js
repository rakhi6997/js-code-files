let promiseObj = new Promise((resolve, reject) => {
    console.log("Getting email from server...");
    setTimeout(() => {
        
        resolve("prachi.agrawal@upgrad.com");
    }, 2000);
});


promiseObj.then((result) => {
    console.log(`Email = ${result}`);
}, (err) => {
    console.log(err);
});