import {hello} from './session41.js';

console.log(hello("Param"));