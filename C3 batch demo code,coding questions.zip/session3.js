var headerTemplate = `<h1>Welcome to Upgrad</h1>`;

document.getElementById("container")
    .innerHTML = headerTemplate;