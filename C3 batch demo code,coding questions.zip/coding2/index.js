// Write your code to get country-wise cities
/* 
Function name should be getCities
You should use XMLHttpRequest to make API request
You should return a Promise from this function basing on the API response
Promise should be resolved by returning the API response in JSON if the response is success
Promise should be rejected by returning the JSON {error: "Failed to GET cities for <country-value>"} if API returns a failure response.
<country-value> should be replaced with the country code entered by the user in the form

*/

function getCities(){
    var xhttp = new XMLHttpRequest();
    let country = document.getElementById('country').value;
    console.log(country);

    xhttp.open("GET", `https://api.openaq.org/v1/cities?country=${country}`, true);
    xhttp.send();

    xhttp.onreadystatechange = function(){
        if(this.readyState === 4 && this.status === 200){
            console.log(JSON.parse(this.responseText).results);
        }
    }
}


if (typeof exports !== "undefined") {
    module.exports = {
      getCities,
    };
  }
  