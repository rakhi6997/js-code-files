// const dishList = document.getElementById("dishList");
// const search = document.getElementById('searchbar');
// let mealList = [];
// let list = [];

// const fetchDishes = async () => {
//     const result = await fetch('https://www.themealdb.com/api/json/v1/1/search.php?s');
//     list = await result.json();
//     mealList = list.meals;
//     printDishes(mealList);
// };

// const printDishes = (dishes)=>{
//     const dishString = dishes.map((dish) => {
//         return `
//             <li class="dishes">
//                 <h3>${dish.strMeal}</h3>
//                 <p>${dish.strArea}</p>
//                 <img src='${dish.strMealThumb}'></img>
//             </li>
//         `;
//     }).join('');
//     dishList.innerHTML = dishString;
// };

// search.addEventListener('keyup', (all) =>{
//     const mealSearch = all.target.value.toLowerCase();
//     const filteredDishes = mealList.filter(dish=>{
//         return dish.strMeal.toLowerCase().includes(mealSearch) 
//         || dish.strArea.toLowerCase().includes(mealSearch) ;
//     });
//     printDishes(filteredDishes);
// })

// fetchDishes();

let list = [];

var getCountries = async () => {
    var xhttp = new XMLHttpRequest();

    xhttp.open("GET", "https://api.openaq.org/v1/countries", true);
    xhttp.send();

    xhttp.onreadystatechange = function(){
        if(this.readyState === 4 && this.status === 200){
            var data = JSON.parse(this.responseText).results;
            var formattedData = data.map(country=>{
                // <p>CountryName CountryCode</p>
                return `<p>${country.name} ${country.code}</p>`
            }).join('');
            document.getElementById('country_data').innerHTML = formattedData;
        }
    }
}

getCountries();