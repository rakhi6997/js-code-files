function func1(){
    alert("Welcome to Upgrad");
}